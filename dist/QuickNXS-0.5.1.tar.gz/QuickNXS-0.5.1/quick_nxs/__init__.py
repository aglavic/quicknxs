import sip
sip.setapi('QString', 2)
sip.setapi('QVariant', 2)

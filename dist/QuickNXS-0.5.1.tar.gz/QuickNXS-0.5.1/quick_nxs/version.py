#-*- coding: utf-8 -*-

# the minor version and change date gets automatically updated on a git commit
version=(0, 5, 1)
last_changes="2013-02-01 16:20"

str_version=".".join(map(str, version))

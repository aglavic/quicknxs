import refl_main_gui

def append(text):
    refl_main_gui.MainGUI.logbook.append(text)
        
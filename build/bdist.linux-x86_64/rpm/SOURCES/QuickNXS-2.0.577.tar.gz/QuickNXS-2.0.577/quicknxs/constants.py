mn = 1.675e-27   #kg
h = 6.626e-34 #m^2 kg s^-1
new_geometry_detector_date = '2014-10-01'
new_si_slits_date = '2014-07-04'
double_click_if_within_time = 0.4  #s

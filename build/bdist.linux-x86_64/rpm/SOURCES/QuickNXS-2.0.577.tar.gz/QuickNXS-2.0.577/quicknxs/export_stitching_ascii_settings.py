class ExportStitchingAsciiSettings(object):
	
	fourth_column_flag = True
	fourth_column_dq0 = 0.05
	fourth_column_dq_over_q = 0.001
	use_lowest_error_value_flag = True
	
	
	
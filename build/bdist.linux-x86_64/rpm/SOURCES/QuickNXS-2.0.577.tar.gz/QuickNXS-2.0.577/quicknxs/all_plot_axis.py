class AllPlotAxis(object):
	
	yt_view_interval = None
	yt_data_interval = None
	is_yt_ylog = False
	is_yt_xlog = False

	detector_view_interval = None
	detector_data_interval = None

	yi_view_interval = None
	yi_data_interval = None
	is_yi_ylog = False
	is_yi_xlog = True
	
	it_view_interval = None
	it_data_interval = None
	is_it_ylog = False
	is_it_xlog = False
	
	ix_view_interval = None
	ix_data_interval = None
	is_ix_ylog = False
	is_it_xlog = False

	reduced_plot_stitching_tab_view_interval = None
	reduced_plot_stitching_tab_data_interval = None
	is_reduced_plot_stitching_tab_ylog = True
	is_reduced_plot_stitching_tab_xlog = False
	
	reduced_plot_overview_tab_view_interval = None
	reduced_plot_overview_tab_data_interval = None
	is_reduced_plot_overview_tab_ylog = True
	is_reduced_plot_overview_tab_xlog = True

	def __init__(self):
		pass
	
		
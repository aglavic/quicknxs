#-*- coding: utf-8 -*-
'''
  doc
'''

config_file=''

ADMIN=u'Jean Bilheux'
ADMIN_EMAIL=u'j35@ornl.gov'
SMTP_SERVER='160.91.4.26'

SCRIPT_VERSION='1.0'

debug_mode=False
default_log_levels={
                    'CONSOLE': 'WARNING',
                    'FILE': 'INFO',
                    'GUI': 'INFO',
                    }
debug_log_levels={
                    'CONSOLE': 'DEBUG',
                    'FILE': 'DEBUG',
                    'GUI': 'INFO',
                    }
pdb_log_levels={
                    'CONSOLE': 'DEBUG',
                    'FILE': 'INFO',
                    'GUI': 'INFO',
                    }

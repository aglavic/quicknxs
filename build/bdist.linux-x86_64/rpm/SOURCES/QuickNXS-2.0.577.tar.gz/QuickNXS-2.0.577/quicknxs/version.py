#-*- coding: utf-8 -*-

# the minor version and change date gets automatically updated on a git commit
version=(2, 0, 577)
last_changes="2015-04-29 12:51:36"

str_version=".".join(map(str, version))

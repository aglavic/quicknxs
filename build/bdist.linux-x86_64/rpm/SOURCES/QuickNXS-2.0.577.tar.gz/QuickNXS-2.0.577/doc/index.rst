.. QuickNXS documentation master file, created by
   sphinx-quickstart on Thu Dec  6 21:26:40 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to QuickNXS's API documentation!
========================================

Contents of the quicknxs Package:

.. toctree::
   :maxdepth: 2
   
   gui
   analysis
   other



Indices and tables
==================

.. toctree::
  
  references

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


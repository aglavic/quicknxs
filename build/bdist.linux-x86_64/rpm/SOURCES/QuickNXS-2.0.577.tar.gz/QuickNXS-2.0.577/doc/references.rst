
Scientific References
=====================

.. [ARWildes2007]   A.R. Wildes, 
                    **Neutron Polarization Analysis Corrections Made Easy**, 
                    *Neutron News* **17:2**, 17-25 (2007)
                      
.. [PDu2006]        P. Du, W.A. Kibbe and S.M. Lin,
                    **Improved peak detection in mass spectrum by incorporating continuous 
                    wavelet transform-based pattern matching**
                    *Bioinformatics* **22**, 17 (2006)

                  
.. [CTorrance1998] C Torrance and GP Compo
                     **A practical guide to wavelet analysis**
                     *Bull Amer Meteor Soc* **79**, 1 61-78 (1998)
